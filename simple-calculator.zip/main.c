#include<stdio.h>
#include<stdlib.h>
void add(int num1,int num2)
{
  printf("Enter the numbers:");
  scanf("%d%d",&num1,&num2);
  if((num1 && num2) != 0)
  {
    printf("The sum of these is %d",num1+num2);
  }
}
void sub(int num1,int num2)
{
   printf("Enter the numbers:");
  scanf("%d%d",&num1,&num2);
  if((num1 && num2) != 0)
   {
    printf("The difference of these is %d",num1-num2);
  }
}
void mul(int num1,int num2)
{
   printf("Enter the numbers:");
  scanf("%d%d",&num1,&num2);
  if(num1 == 0 || num2 == 0)
  {
    printf("The multiple of these is 'zero'");
  }
  else
  {
    printf("The multiple of these is %d",num1*num2);
  }
}
void divi(int num1,int num2)
{
  printf("Enter the numbers:");
  scanf("%d%d",&num1,&num2);
  if(num1 == 0)
  {
    printf("The division of these is 'zero'");
  }
  else if(num2 == 0)
  {
    printf("the division of these id 'INFINITY'");
  }
  else
  {
    printf("The division of these is %d",num1/num2);
  }
}
void main()
{
  int num,num1,num2;
  while(1)
  {
    printf("\n--SIMPLE CALCULATOR--");
    printf("\n1.Addition\n2.Subtration\n3.Multiplication\n4.Division\n5.Exit\n");
    printf("Enter the number you want use::");
    scanf("%d",&num);
    switch(num)
    {
      case 1: add(num1,num2);
              break;
      case 2: sub(num1,num2);
              break;
      case 3: mul(num1,num2);
              break;
      case 4: divi(num1,num2);
              break;
      case 5: exit(0);
            
    }
  }
}